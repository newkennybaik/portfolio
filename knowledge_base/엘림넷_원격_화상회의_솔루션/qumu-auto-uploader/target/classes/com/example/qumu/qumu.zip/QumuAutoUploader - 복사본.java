package com.example.qumu;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.time.Duration;
import java.util.Locale;
import java.util.stream.Stream;

public class QumuAutoUploader {

    private static final String INSTANCE   = env("QUMU_INSTANCE", "demo");
    private static final String USERNAME   = env("QUMU_USERNAME", "you@example.com");
    private static final String PASSWORD   = env("QUMU_PASSWORD", "password");
    private static final String TYPE_GUID  = env("QUMU_TYPE_GUID", "");
    private static final String TYPE_TITLE = env("QUMU_TYPE_TITLE", "");
    private static final String WATCH_PATH = env("WATCH_PATH",
            Paths.get(System.getProperty("user.home"), "qumu-watch").toString());
    private static final long   POLL_MS    = Long.parseLong(env("QUMU_POLL_MS", "15000"));

    public static void main(String[] args) throws Exception {
        System.out.println("[CONFIG] INSTANCE=" + INSTANCE);
        System.out.println("[CONFIG] WATCH_PATH=" + WATCH_PATH);

        Files.createDirectories(Path.of(WATCH_PATH));

        try (QumuClient qumu = new QumuClient(INSTANCE, USERNAME, PASSWORD)) {

            final String resolvedTypeGuid = resolveTypeGuidOrAuto(qumu, TYPE_GUID, TYPE_TITLE);
            System.out.println("[CONFIG] TYPE_GUID=" + resolvedTypeGuid);

            try (Stream<Path> s = Files.list(Path.of(WATCH_PATH))) {
                s.filter(Files::isRegularFile)
                 .map(Path::toFile)
                 .filter(QumuAutoUploader::isVideo)
                 .forEach(f -> safeProcess(qumu, f, resolvedTypeGuid));
            }

            WatchService ws = FileSystems.getDefault().newWatchService();
            Path dir = Path.of(WATCH_PATH);
            dir.register(ws, StandardWatchEventKinds.ENTRY_CREATE);
            System.out.println("[WATCH] " + dir);

            while (true) {
                WatchKey key = ws.take();
                for (WatchEvent<?> e : key.pollEvents()) {
                    if (e.kind() != StandardWatchEventKinds.ENTRY_CREATE) continue;
                    Path created = dir.resolve((Path) e.context());
                    File f = created.toFile();
                    if (!f.isFile()) continue;
                    if (!isVideo(f)) continue;
                    waitUntilStable(f, Duration.ofSeconds(5));
                    safeProcess(qumu, f, resolvedTypeGuid);
                }
                key.reset();
            }
        }
    }

    private static void safeProcess(QumuClient qumu, File file, String typeGuid) {
        try {
            String name  = file.getName();
            String title = name.contains(".") ? name.substring(0, name.lastIndexOf('.')) : name;

            System.out.println("[CREATE] " + title);
            String kuluGuid = qumu.createKulu(title, typeGuid);
            System.out.println("[GUID]   " + kuluGuid);

            System.out.println("[UPLOAD] " + name);
            qumu.uploadMedia(kuluGuid, file);

         // 업로드 직후
            while (true) {
                Thread.sleep(POLL_MS);

                String state = qumu.getState(kuluGuid);
                System.out.println("[STATE]  " + kuluGuid + " -> " + state);
                if ("PUBLISHED".equalsIgnoreCase(state)) break;

                // 상태가 무엇이든(FAILED 제외) 발행 시도: 허용 시점에 서버가 반영
                try {
                    qumu.publish(kuluGuid);
                    System.out.println("[PUBLISH] requested");
                } catch (Exception ignore) {
                    // 인코딩/정책 때문에 거절되면 다음 루프에서 재시도
                }

                if ("FAILED".equalsIgnoreCase(state)) {
                    throw new RuntimeException("Encoding failed for " + kuluGuid);
                }
            }

            System.out.println("[DONE]   https://" + INSTANCE + ".qumucloud.com/view/" + kuluGuid);
        } catch (Exception ex) {
            System.err.println("[ERROR]  " + file.getName() + " : " + ex.getMessage());
            ex.printStackTrace(System.err);
        }
    }

    private static boolean isVideo(File f) {
        String n = f.getName().toLowerCase(Locale.ROOT);
        return n.endsWith(".mp4") || n.endsWith(".avi");
    }

    private static void waitUntilStable(File f, Duration stableFor) throws InterruptedException, IOException {
        long lastSize = -1, stableMillis = 0;
        while (stableMillis < stableFor.toMillis()) {
            long size = Files.size(f.toPath());
            if (size == lastSize) {
                Thread.sleep(500);
                stableMillis += 500;
            } else {
                lastSize = size;
                stableMillis = 0;
                Thread.sleep(500);
            }
        }
    }

    private static String resolveTypeGuidOrAuto(QumuClient qumu, String guid, String title) throws IOException {
        if (guid != null && !guid.isBlank()) {
            try { return qumu.resolveTypeGuid(guid); } catch (IOException ignore) { /* try title/auto */ }
        }
        if (title != null && !title.isBlank()) {
            try { return qumu.resolveTypeGuid(title); } catch (IOException ignore) { /* try auto */ }
        }
        // auto-pick: prefer type with no required metadata, otherwise first one
        String autoGuid = qumu.chooseTypeGuidAuto();
        System.out.println("[INFO] No TYPE_GUID/TITLE provided. Auto-picked type GUID: " + autoGuid);
        return autoGuid;
    }

    private static String env(String k, String def) {
        String v = System.getenv(k);
        return (v == null || v.isBlank()) ? def : v;
    }
}
